G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*
G04 #@! TF.CreationDate,2026-10-28T21:59:23+10:30*
G04 #@! TF.ProjectId,ring_ir_prog_anvil,72696e67-5f69-4725-9f70-726f675f616e,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-10-28 21:59:23*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,1.500000*%
%ADD11R,6.000000X1.241000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J1*
X150000000Y-108951400D03*
G04 #@! TD*
D11*
G04 #@! TO.C,P8*
X150000000Y-103409700D03*
G04 #@! TD*
M02*
